﻿using System;
using System.ComponentModel;
/*
 * name 테이블
 * Class Name	Class Type
Tico	D
Accent	D
Morning	D
K311	D
Twizy	D
Martiz	D
Spark	D
Casper	D

Avante	C
Sonata	C
Grandeur	C
K3	C
K5	C
Camry	C
Rav4	C
Ls300	C
G80	C
G90	C
K7	C
K8	C
Gv60	C
Gv80	C
Niro	C
Santafe	C
Seltos	C
Sportage	C
Mohave	C
Palisade	C
Torres	C
Korando	C
Sorento	C
Sm5	C

VelosterN	B
G70	B
Camaro	B
Mustang	B
M3	B
ClaAmg45	B
AvanteN	B
DodgeChallenger	B
M340i	B
C43	B
AudiA6	B
Model3	B
Ev6	B
Stinger	B
TypeF	B

LexusLFA	A
McLaren720S	A
PorcheTaycan	A
M5	A
SkylineGTR	A
CorvetteC8	A
Amg63Gt	A
AudiR8	A

ZondaR	S
LamboVeneno	S
AmgOne	S
BugattiDivo	S
 */
namespace Project_TheCar
{
    public abstract class Car //Car의 객체 속성 추상화
    {
        public string Name;//componant 속성 설정. 차량에 이런 요소들이 있다!
        public int MaxSpeed;
        public double Accel;
        public int Weight;
        public char Class;
        public String Explain;
        public int Number; //차고 데이터 베이스 추가
    }

    class Default : Car
    {
        public Default()
        {
            Name = "default";
            MaxSpeed = 0;
            Accel = 0;
            Weight = 0;
            Class = 'X';
            Explain = "default";
            Number = 0;
        }
    }
    //여기서부턴 D클래스
    class Tico : Car
    {
        public Tico()
        {
            Name = "티코";
            MaxSpeed = 41;
            Accel = 6;
            Weight = 650;
            Class = 'D';
            Explain = "티코!";
            Number = 1;
        }
    }
    class Accent : Car
    {
        public Accent()
        {
            Name = "악센트";
            MaxSpeed = 113;
            Accel = 14;
            Weight = 965;
            Class = 'D';
            Explain = "현대 악센트";
            Number = 2;
        }
    }
    class Morning : Car
    {
        public Morning()
        {
            Name = "모닝";
            MaxSpeed = 76;
            Accel = 9.7;
            Weight = 910;
            Class = 'D';
            Explain = "기아 모닝";
            Number = 3;
        }
    }
    class K311 : Car
    {
        public K311()
        {
            Name = "K-311";
            MaxSpeed = 115;
            Accel = 37;
            Weight = 2550;
            Class = 'D';
            Explain = "대한민국 군 특수차량 K-311" +
                      "운전병들에게는 쓰리쿼터라는 별명으로 유명하다." +
                      "매우 느리며 변속도 아주 불편하고 승차감이 아주 안좋은 차량이다" +
                      "특히 에어컨이 나오지 않고, 천장이 천막으로 되어있어 여름철에 운전병들에게 지옥을 선사한다.";
            Number = 4;
        }
    }
    class Casper : Car
    {
        public Casper()
        {
            Name = "캐스퍼";
            MaxSpeed = 76;
            Accel = 9.7;
            Weight = 1020;
            Class = 'D';
            Explain = "현대 캐스퍼. 귀엽고 조그만해서 초보들의 첫차로 추천된다" +
                      "매우 작아보이지많 의외로 일본에서는 경차로 인정되지 않는다고 한다.";
            Number = 5;
        }
    }
    class Twizy : Car
    {
        public Twizy()
        {
            Name = "트위지";
            MaxSpeed = 17;
            Accel = 0.6;
            Weight = 910;
            Class = 'D';
            Explain = "르노 트위지. 1인승 전기차량이다. 쥐처럼 생겼다";
            Number = 6;
        }
    }
    class Martiz : Car
    {
        public Martiz()
        {
            Name = "마티즈";
            MaxSpeed = 70;
            Accel = 9.4;
            Weight = 910;
            Class = 'D';
            Explain = "지금은 사라져버린 GM 마티즈" +
                      "빨간마티즈와 황금마티즈를 조심하자";
            Number = 7;
        }
    }
    class Spark : Car
    {
        public Spark()
        {
            Name = "스파크";
            MaxSpeed = 75;
            Accel = 9.7;
            Weight = 900;
            Class = 'D';
            Explain = "마티즈의 뒤를 잇는 GM 스파크";
            Number = 8;
        }
    }
    /// <summary>
    /// 여기서부턴 C클래스 차량 입니다.
    /// </summary>
    class Avante : Car //아반떼 객체
    {
        public Avante()//차량마다 다른 속성값은 각각의 클래스에서 넣어라
        {//일단 얘는 생성자임 -> 초기화
            Name = "아반떼";
            MaxSpeed = 123;
            Accel = 15.7;
            Weight = 1335;
            Class = 'C';
            Explain = "현대자동차의 전륜구동 기반 준중형 세단.\n" +
                      "공식적으로는 엘란트라의 2세대 모델부터 대한민국 국내에서의 시판 차명을 모두 통칭한다.\n" +
                      "현대자동차의 차량 중 최초로 1천만대를 넘어섰다.\n" +
                      "즉, 한국산 차량 중 세계에서 가장 많은 판매량을 자랑하는 차종이라고 할 수 있다.\n" +
                      "국내에서도 승용차종 항목에서 연간 및 월간 판매량 1위를 놓고 K3와 경쟁하는 " +
                      "베스트셀러 차종이다.\n" +
                      "해외에서도 동급 세그먼트 판매량 5위 안팎을 왔다갔다하는 " +
                      "글로벌 베스트셀링 차종이다.";
            Number = 9;
        }
    }
    class Sonata : Car
    {
        public Sonata()
        {
            Name = "소나타";
            MaxSpeed = 160;
            Accel = 20.0;
            Weight = 1525;
            Class = 'C';
            Explain = "현대자동차에서 1985년부터 생산하는 전륜구동 중형 세단이다.\n" +
                      "2023년 기준으로 38년째 생산되고 있으며, 대한민국의 승용차 브랜드 중 가장 오래됐다.\n " +
                      "현대자동차의 전 모델 가운데 통산 판매량 3번째를 기록하고 있다\n" +
                      "아반떼, 그랜저와 함께 현대를 대표하는 3대 세단 라인업 중 하나이다. \n" +
                      "국민차 하면 가장 먼저 떠오르는 명실상부한 대한민국 대표 승용차였으며, " +
                      "내수 수출을 통틀어 현대자동차의 간판 모델이라고 볼 수 있다.\n";
            Number = 10;
        }
    }
    class Grandeur : Car
    {
        public Grandeur()
        {
            Name = "그랜저";
            MaxSpeed = 198;
            Accel = 25.3;
            Weight = 1635;
            Class = 'C';
            Explain = "현대자동차에서 출시한 준대형 세단이자 플래그십 모델이다.\n" +
                      "아반떼, 쏘나타와 함께 현대자동차를 대표하는 3대 세단 라인업 중 하나로 1986년에 처음 출시된 이래 지금도 그 이름을 이어가는 중이며\n" +
                      "쏘나타, 포터, 마이티와 함께 장수모델 중 하나이다.";
            Number = 11;
        }
    }
    class K3 : Car
    {
        public K3()
        {
            Name = "K3";
            MaxSpeed = 123;
            Accel = 15.7;
            Weight = 1260;
            Class = 'C';
            Explain = "기아의 아반떼";
            Number = 12;
        }
    }
    class K5 : Car
    {
        public K5()
        {
            Name = "K5";
            MaxSpeed = 180;
            Accel = 27;
            Weight = 1450;
            Class = 'C';
            Explain = "The Korean 양카";
            Number = 13;
        }
    }
    class Camry : Car
    {
        public Camry()
        {
            Name = "토요타 캠리";
            MaxSpeed = 207;
            Accel = 24.8;
            Weight = 1560;
            Class = 'C';
            Explain = "토요타에서 미국 시장을 타겟으로 만든 중형 세단이며, 20년이 넘도록 미국에서 세단 판매량 1위를 고수하고 있는 최고 인기 패밀리 세단이다.";
            Number = 14;
        }
    }
    class Rav4 : Car
    {
        public Rav4()
        {
            Name = "토요타 Rav4";
            MaxSpeed = 178;
            Accel = 22.7;
            Weight = 1930;
            Class = 'C';
            Explain = "일본의 자동차 제조사 토요타에서 1994년부터 생산중인 준중형 SUV로, 토요타 최초의 컴팩트 크로스오버 SUV이다.\n" +
                      "컴팩트카의 기동성과 연비를 원하지만 또한 SUV(큰 짐칸, 높은 시야, 그리고 항시 사륜구동 등)의 장점을 누리고 싶어하는 소비자들을 겨냥해 라브4를 개발했다.";
            Number = 15;
        }
    }
    class Ls300 : Car
    {
        public Ls300()
        {
            Name = "LEXUS LS300";
            MaxSpeed = 175;
            Accel = 23;
            Weight = 1715;
            Class = 'C';
            Explain = "일본의 럭셔리 자동차 브랜드 LEXUS를 대표하는 차량. 고급스런 외관, 높은 연비, 고장나지 않는 내구성이 유명하다.";
            Number = 16;
        }
    }
    class G80 : Car
    {
        public G80()
        {
            Name = "G80";
            MaxSpeed = 304;
            Accel = 43;
            Weight = 1785;
            Class = 'C';
            Explain = "The Genesis G80.";
            Number = 17;
        }
    }
    class G90 : Car
    {
        public G90()
        {
            Name = "G90";
            MaxSpeed = 380;
            Accel = 54;
            Weight = 2025;
            Class = 'C';
            Explain = "The Genesis G90.";
            Number = 18;
        }
    }
    class K7 : Car
    {
        public K7()
        {
            Name = "K7";
            MaxSpeed = 159;
            Accel = 21;
            Weight = 1600;
            Class = 'C';
            Explain = "기아의 고급세단. 현재는 단종되었다.";
            Number = 19;
        }
    }
    class K8 : Car
    {
        public K8()
        {
            Name = "K8";
            MaxSpeed = 230;
            Accel = 35;
            Weight = 1650;
            Class = 'C';
            Explain = "K7의 뒤를 잇는 기아의 고급세단. 멋진 디자인이 호평받는다";
            Number = 20;
        }
    }
    class Gv60 : Car
    {
        public Gv60()
        {
            Name = "GV60";
            MaxSpeed = 225;
            Accel = 35.7;
            Weight = 1985;
            Class = 'C';
            Explain = "제네시스 엔트리 라인업의 SUV. 성능에 비해 가격이 비싸다";
            Number = 21;
        }
    }
    class Gv80 : Car
    {
        public Gv80()
        {
            Name = "GV80";
            MaxSpeed = 304;
            Accel = 43;
            Weight = 2040;
            Class = 'C';
            Explain = "제네시스의 메인 SUV. 굉장한 성능과 인테리어를 자랑한다";
            Number = 22;
        }
    }
    class Niro : Car
    {
        public Niro()
        {
            Name = "기아 니로";
            MaxSpeed = 204;
            Accel = 41;
            Weight = 1760;
            Class = 'C';
            Explain = "기아의 엔트리급 전기차. 택시로 애용된다." +
                      "부산 택시 아저씨들의 난폭한 운전 솜씨와 전기차의 제로백이 합쳐져 탑승자에게 끔찍한 경험을 선사한다.";
            Number = 23;
        }

    }
    class Santafe : Car
    {
        public Santafe()
        {
            Name = "싼타페";
            MaxSpeed = 194;
            Accel = 45;
            Weight = 1770;
            Class = 'C';
            Explain = "현대의 주력 중형 SUV";
            Number = 24;
        }
    }
    class Seltos : Car
    {
        public Seltos()
        {
            Name = "셀토스";
            MaxSpeed = 198;
            Accel = 27;
            Weight = 1405;
            Class = 'C';
            Explain = "기아의 주력 소형 SUV";
            Number = 25;
        }
    }
    class Sportage : Car
    {
        public Sportage()
        {
            Name = "스포티지";
            MaxSpeed = 180;
            Accel = 27;
            Weight = 1555;
            Class = 'C';
            Explain = "기아의 주력 준중형 SUV";
            Number = 26;
        }
    }
    class Mohave : Car
    {
        public Mohave()
        {
            Name = "모하비";
            MaxSpeed = 257;
            Accel = 57.1;
            Weight = 2280;
            Class = 'C';
            Explain = "기아의 주력 준대형 SUV";
            Number = 27;
        }
    }
    class Palisade : Car
    {
        public Palisade()
        {
            Name = "팰리세이드";
            MaxSpeed = 202;
            Accel = 45;
            Weight = 1995;
            Class = 'C';
            Explain = "현대의 주력 준대형 SUV";
            Number = 28;
        }
    }
    class Torres : Car
    {
        public Torres()
        {
            Name = "토레스";
            MaxSpeed = 170;
            Accel = 28.6;
            Weight = 1520;
            Class = 'C';
            Explain = "쌍용의 화려한 부활";
            Number = 29;
        }
    }
    class Korando : Car
    {
        public Korando()
        {
            Name = "코란도";
            MaxSpeed = 170;
            Accel = 28.6;
            Weight = 1470;
            Class = 'C';
            Explain = "쌍용의 메인 SUV";
            Number = 30;
        }
    }
    class Sorento : Car
    {
        public Sorento()
        {
            Name = "쏘렌토";
            MaxSpeed = 194;
            Accel = 45;
            Weight = 1770;
            Class = 'C';
            Explain = "기아 쏘렌토";
            Number = 31;
        }
    }
    class Sm5 : Car
    {
        public Sm5()
        {
            Name = "SM5";
            MaxSpeed = 141;
            Accel = 19.8;
            Weight = 1415;
            Class = 'C';
            Explain = "르노 삼성 SM5";
            Number = 32;
        }
    }
    //여기서부턴 B클래스
    class VelosterN : Car
    {
        public VelosterN()
        {
            Name = "벨로스터N";
            MaxSpeed = 275;
            Accel = 36;
            Weight = 1460;
            Class = 'B';
            Explain = "WRC(월드 랠리 챔피언쉽) 우승의 주역. 현대의 명기 벨로스터N";
            Number = 33;

        }
    }
    class G70 : Car
    {
        public G70()
        {
            Name = "G70";
            MaxSpeed = 304;
            Accel = 43;
            Weight = 1660;
            Class = 'B';
            Explain = "제네시스의 자존심. The Sports G70";
            Number = 34;
        }
    }
    class Camaro : Car
    {
        public Camaro()
        {
            Name = "카마로";
            MaxSpeed = 453;
            Accel = 63;
            Weight = 1715;
            Class = 'B';
            Explain = "범블비로 유명한 쉐보레 카마로." +
                      "포드 머스탱과 라이벌이다.";
            Number = 35;
        }
    }
    class Mustang : Car
    {
        public Mustang()
        {
            Name = "머스탱";
            MaxSpeed = 446;
            Accel = 54.1;
            Weight = 1795;
            Class = 'B';
            Explain = "미국의 스포츠 세단 2대장 포드 머스탱." +
                      "쉐보레 카마로와 라이벌이다.";
            Number = 36;

        }
    }
    class M3 : Car
    {
        public M3()
        {
            Name = "BMW M3";
            MaxSpeed = 510;
            Accel = 66.3;
            Weight = 1890;
            Class = 'B';
            Explain = "BMW의 명작 E세그먼트의 최강자. BMW_M3" +
                      "생긴게 일반 bmw와 똑같아서 차알못은 구분을 못한다는게 단점";
            Number = 37;
        }
    }
    class ClaAmg45 : Car
    {
        public ClaAmg45()
        {
            Name = "메르세데스 벤츠 AMG 45";
            MaxSpeed = 421;
            Accel = 51;
            Weight = 1700;
            Class = 'B';
            Explain = "BENZ AMG의 엔트리. AMG45" +
                      "럭셔리 벤츠는 가라!";
            Number = 38;
        }
    }
    class AvanteN : Car
    {
        public AvanteN()
        {
            Name = "아반떼N";
            MaxSpeed = 280;
            Accel = 40;
            Weight = 1485;
            Class = 'B';
            Explain = "현대의 스포츠 라인업 N의 대표작 아반떼 N" +
                      "아반떼 주제에 가격이 4000만원이 넘어가기 때문에" +
                      "\"오빠 이돈이면 벤츠를 사야지 이걸 왜사\" 라는 말이 나오게 된다는 주범.";
            Number = 39;
        }
    }
    class DodgeChallenger : Car
    {
        public DodgeChallenger()
        {
            Name = "닷지 챌린저";
            MaxSpeed = 852;
            Accel = 106.6;
            Weight = 1941;
            Class = 'B';
            Explain = "머슬카의 끝판왕 DODGE CHALLENGER";
            Number = 40;
        }
    }
    class M340i : Car
    {
        public M340i()
        {
            Name = "BMW M340i";
            MaxSpeed = 387;
            Accel = 51;
            Weight = 1715;
            Class = 'B';
            Explain = "BMW 소비자용 3시리즈의 제왕";
            Number = 41;
        }
    }
    class C43 : Car
    {
        public C43()
        {
            Name = "BENZ C43 AMG";
            MaxSpeed = 390;
            Accel = 53;
            Weight = 1765;
            Class = 'B';
            Explain = "";
            Number = 42;
        }
    }
    class AudiA6 : Car
    {
        public AudiA6()
        {
            Name = "AudiA6";
            MaxSpeed = 286;
            Accel = 63.2;
            Weight = 2020;
            Class = 'B';
            Explain = "";
            Number = 43;
        }
    }
    class Model3 : Car
    {
        public Model3()
        {
            Name = "Model3";
            MaxSpeed = 482;
            Accel = 67.3;
            Weight = 1830;
            Class = 'B';
            Explain = "TESLA MODEL3";
            Number = 44;
        }
    }
    class Ev6 : Car
    {
        public Ev6()
        {
            Name = "Ev6";
            MaxSpeed = 576;
            Accel = 75.5;
            Weight = 2160;
            Class = 'B';
            Explain = "KIA Ev6";
            Number = 45;
        }
    }
    class Stinger : Car
    {
        public Stinger()
        {
            Name = "기아 스팅어";
            MaxSpeed = 373;
            Accel = 52;
            Weight = 1775;
            Class = 'B';
            Explain = "KIA 스팅어";
            Number = 46;
        }
    }
    class TypeF : Car
    {
        public TypeF()
        {
            Name = "재규어 TypeF";
            MaxSpeed = 575;
            Accel = 71.4;
            Weight = 1875;
            Class = 'B';
            Explain = "재규어";
            Number = 47;
        }
    }
    //여기서부턴 A클래스
    class LexusLFA : Car
    {
        public LexusLFA()
        {
            Name = "Lexus LFA";
            MaxSpeed = 560;
            Accel = 49;
            Weight = 1480;
            Class = 'A';
            Explain = "렉서스 스포츠카";
            Number = 48;
        }
    }
    class McLaren720S : Car
    {
        public McLaren720S()
        {
            Name = "McLaren720S";
            MaxSpeed = 740;
            Accel = 58;
            Weight = 1188;
            Class = 'A';
            Explain = "";
            Number = 49;
        }
    }
    class PorcheTaycan : Car
    {
        public PorcheTaycan()
        {
            Name = "PorcheTaycan";
            MaxSpeed = 590;
            Accel = 86.7;
            Weight = 2315;
            Class = 'A';
            Explain = "";
            Number = 50;
        }
    }
    class M5 : Car
    {
        public M5()
        {
            Name = "BMW M5";
            MaxSpeed = 625;
            Accel = 76.5;
            Weight = 1950;
            Class = 'A';
            Explain = "";
            Number = 51;
        }
    }
    class SkylineGTR : Car
    {
        public SkylineGTR()
        {
            Name = "SkylineGTR";
            MaxSpeed = 600;
            Accel = 66.5;
            Weight = 1700;
            Class = 'A';
            Explain = "";
            Number = 52;
        }
    }
    class CorvetteC8 : Car
    {
        public CorvetteC8()
        {
            Name = "CorvetteC8";
            MaxSpeed = 655;
            Accel = 65;
            Weight = 1750;
            Class = 'A';
            Explain = "";
            Number = 53;
        }
    }
    class Amg63Gt : Car
    {
        public Amg63Gt()
        {
            Name = "벤츠 AMG63 GT";
            MaxSpeed = 730;
            Accel = 81.6;
            Weight = 1665;
            Class = 'A';
            Explain = "";
            Number = 54;
        }
    }
    class AudiR8 : Car
    {
        public AudiR8()
        {
            Name = "AudiR8";
            MaxSpeed = 610;
            Accel = 57.1;
            Weight = 1695;
            Class = 'A';
            Explain = "";
            Number = 55;
        }
    }
    //여기서부턴 S클래스
    class ZondaR : Car
    {
        public ZondaR()
        {
            Name = "파가니 존다 R";
            MaxSpeed = 800;
            Accel = 72.4;
            Weight = 1280;
            Class = 'S';
            Explain = "1280";
            Number = 56;
        }
    }
    class LamboVeneno : Car
    {
        public LamboVeneno()
        {
            Name = "람보르기니 베네노";
            MaxSpeed = 750;
            Accel = 70.4;
            Weight = 1695;
            Class = 'S';
            Explain = "1490";
            Number = 57;
        }
    }
    class AmgOne : Car
    {
        public AmgOne()
        {
            Name = "벤츠 AMG-ONE";
            MaxSpeed = 1063;
            Accel = 102;
            Weight = 1695;
            Class = 'S';
            Explain = "1490";
            Number = 58;
        }
    }
    class BugattiDivo : Car
    {
        public BugattiDivo()
        {
            Name = "부가티 디보";
            MaxSpeed = 1500;
            Accel = 168;
            Weight = 1950;
            Class = 'S';
            Explain = "세계에서 가장 빠른 하이퍼카";
            Number = 59;
        }
    }
    public abstract class CarFactory //car 팩토리 추상화(차량 생산공장은 어떻게 생겼을까?)
    {
        public abstract Car Factory_Cars(int name);//팩토리의 형태 정해주기(이렇게 생겼음 ㅋㅋ)
                                                   //소나타 그랜저 제네시스 생산할때도 같은 공장 형태를 유지해야 관리하기 편함
    }

    public class Factory : CarFactory
    {
        public override Car Factory_Cars(int name)
        {
            // 1~8 'D'
            // 9~32 'C'
            // 33~47 'B'
            // 48~55 'A'
            // 56~59 'S'
            switch (name)
            {
                case 1://여기서부턴 D클래스입니다.
                    return new Tico();
                    break;
                case 2:
                    return new Accent();
                    break;
                case 3:
                    return new Morning();
                    break;
                case 4:
                    return new K311();
                    break;
                case 5:
                    return new Twizy();
                    break;
                case 6:
                    return new Martiz();
                    break;
                case 7:
                    return new Spark();
                    break;
                case 8:
                    return new Casper();
                    break;
                case 9://여기서부터는 C클래스입니다
                    return new Avante();
                    break;
                case 10:
                    return new Sonata();
                    break;
                case 11:
                    return new Grandeur();
                    break;
                case 12:
                    return new K3();
                    break;
                case 13:
                    return new K5();
                    break;
                case 14:
                    return new Camry();
                    break;
                case 15:
                    return new Rav4();
                    break;
                case 16:
                    return new Ls300();
                    break;
                case 17:
                    return new G80();
                    break;
                case 18:
                    return new G90();
                    break;
                case 19:
                    return new K7();
                    break;
                case 20:
                    return new K8();
                    break;
                case 21:
                    return new Gv60();
                    break;
                case 22:
                    return new Gv80();
                    break;
                case 23:
                    return new Niro();
                    break;
                case 24:
                    return new Santafe();
                    break;
                case 25:
                    return new Seltos();
                    break;
                case 26:
                    return new Sportage();
                    break;
                case 27:
                    return new Mohave();
                    break;
                case 28:
                    return new Palisade();
                    break;
                case 29:
                    return new Torres();
                    break;
                case 30:
                    return new Korando();
                    break;
                case 31:
                    return new Sorento();
                    break;
                case 32:
                    return new Sm5();
                    break;
                case 33://여기서부터는 B클래스 차량입니다
                    return new VelosterN();
                    break;
                case 34:
                    return new G70();
                    break;
                case 35:
                    return new Camaro();
                    break;
                case 36:
                    return new Mustang();
                    break;
                case 37:
                    return new M3();
                    break;
                case 38:
                    return new ClaAmg45();
                    break;
                case 39:
                    return new AvanteN();
                    break;
                case 40:
                    return new DodgeChallenger();
                    break;
                case 41:
                    return new M340i();
                    break;
                case 42:
                    return new C43();
                    break;
                case 43:
                    return new AudiA6();
                    break;
                case 44:
                    return new Model3();
                    break;
                case 45:
                    return new Ev6();
                    break;
                case 46:
                    return new Stinger();
                    break;
                case 47:
                    return new TypeF();
                    break;
                case 48://여기서부터는 A클래스
                    return new LexusLFA();
                    break;
                case 49:
                    return new McLaren720S();
                    break;
                case 50:
                    return new PorcheTaycan();
                    break;
                case 51:
                    return new M5();
                    break;
                case 52:
                    return new SkylineGTR();
                    break;
                case 53:
                    return new CorvetteC8();
                    break;
                case 54:
                    return new Amg63Gt();
                    break;
                case 55:
                    return new AudiR8();
                    break;
                case 56://여기서부턴 S클래스
                    return new ZondaR();
                    break;
                case 57:
                    return new LamboVeneno();
                    break;
                case 58:
                    return new AmgOne();
                    break;
                case 59:
                    return new BugattiDivo();
                    break;
                default:
                    return new Default();
                    break;
            }
        }
    }
}