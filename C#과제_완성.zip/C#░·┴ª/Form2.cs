﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using C_과제;
using CarStore;
using Microsoft.VisualBasic.ApplicationServices;
using Project_TheCar;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace C_과제
{
	public partial class Form2 : Form
	{
		// 공용으로 되는 값 선언
		public int reward_money;
		public Com com_c = new Com();
		public User user_c = new User();

		public Form2(int garagecar_count)
		{
			InitializeComponent();
			this.Size = new Size(1080, 600);
			this.BackColor = Color.SkyBlue;
			// factory 
			Factory factory = new Factory();
			for (int i = 1; i < 60; i++)
			{
				var a = factory.Factory_Cars(i);
				// Gacha클래스의 garage_count[i]번째 값이 0보다 크다면 즉 1개라도 있다면 
				if (Gacha.garage_count[i] > 0)
				{
					//combo상자에 해당 차량의 Name을 추가한다
					comboBox1.Items.Add(a.Name);
				}
			}
		}

		// 서울맵
		private void pictureBox1_Click(object sender, EventArgs e)
		{
			// 사용자 차량 객체 불러오기
			double user = user_c.get_power();
			if (user == 0) // 사용자 차량이 안불러와졌다면
			{
				int a = Gacha.usedmoney();
				reward_money = 0;
				a += reward_money;
				DialogResult result1 = MessageBox.Show("사용자 차량을 선택하세요!", "The Car");
				// 사용자 차량 객체 선택 안했을시
				if (result1 == DialogResult.OK)
				{
					this.Hide();
					Form1 form1 = new Form1(a);
					form1.FormClosed += Form1_FormClosed;
					form1.Show();
				}
			}
			// 사용자 차량을 선택했다면
			else
			{
				// 사용했던 돈을 불러옴
				int a = Gacha.usedmoney();
				double com = com_c.get_power();
				// 부가요소 +-*/
				com += 3;
				user -= 10;

				if (user > com)
				{
					// 보상
					reward_money = 1000;
					a += reward_money;
					DialogResult result = MessageBox.Show("User: " + user_c.car_Name() + "\nComputer: " + com_c.car_Name() + "\n 승리자: User, 상금: " + reward_money, "서울");
					// 메시지 창 종료
					if (result == DialogResult.OK)
					{
						this.Hide();
						Form1 form1 = new Form1(a); // 해당 돈을 다시 Form1로 보내 매번 갱신
						form1.FormClosed += Form1_FormClosed;
						form1.Show();
					}
				}
				else
				{
					reward_money = 200;
					a += reward_money;
					DialogResult result = MessageBox.Show("User: " + user_c.car_Name() + "\nComputer: " + com_c.car_Name() + "\n 승리자: Computer, 상금: " + reward_money, "서울");
					// 메시지 창 종료
					if (result == DialogResult.OK)
					{
						this.Hide();
						Form1 form1 = new Form1(a);
						form1.FormClosed += Form1_FormClosed;
						form1.Show();
					}
				}
			}
		}
		// 부산맵
		private void pictureBox2_Click(object sender, EventArgs e)
		{
			// 사용자 차량 객체 불러오기
			double user = user_c.get_power();
			if (user == 0)
			{
				int a = Gacha.usedmoney();
				reward_money = 0;
				a += reward_money;
				DialogResult result1 = MessageBox.Show("사용자 차량을 선택하세요!", "The Car");
				// 사용자 차량 객체 선택 안했을시
				if (result1 == DialogResult.OK)
				{
					this.Hide();
					Form1 form1 = new Form1(a);
					form1.FormClosed += Form1_FormClosed;
					form1.Show();
				}
			}
			// 사용자 차량을 선택했다면
			else
			{
				int a = Gacha.usedmoney();
				double com = com_c.get_power();
				// 부가요소 +
				com += 5;
				user -= 7;
				if (user > com)
				{
					reward_money = 1000;
					a += reward_money;
					DialogResult result = MessageBox.Show("User: " + user_c.car_Name() + "\nComputer: " + com_c.car_Name() + "\n 승리자: User, 상금: " + reward_money, "부산");
					// 메시지 창 종료
					if (result == DialogResult.OK)
					{
						this.Hide();
						Form1 form1 = new Form1(a);
						form1.FormClosed += Form1_FormClosed;
						form1.Show();
					}
				}
				else
				{
					reward_money = 200;
					a += reward_money;
					DialogResult result = MessageBox.Show("User: " + user_c.car_Name() + "\nComputer: " + com_c.car_Name() + "\n 승리자: Computer, 상금: " + reward_money, "부산");
					// 메시지 창 종료
					if (result == DialogResult.OK)
					{
						this.Hide();
						Form1 form1 = new Form1(a);
						form1.FormClosed += Form1_FormClosed;
						form1.Show();
					}
				}
			}
		}
		// 인천맵
		private void pictureBox4_Click(object sender, EventArgs e)
		{
			// 사용자 차량 객체 불러오기
			double user = user_c.get_power();
			if (user == 0)
			{
				int a = Gacha.usedmoney();
				reward_money = 0;
				a += reward_money;
				DialogResult result1 = MessageBox.Show("사용자 차량을 선택하세요!", "The Car");
				// 사용자 차량 객체 선택 안했을시
				if (result1 == DialogResult.OK)
				{
					this.Hide();
					Form1 form1 = new Form1(a);
					form1.FormClosed += Form1_FormClosed;
					form1.Show();
				}
			}
			// 사용자 차량을 선택했다면
			else
			{
				int a = Gacha.usedmoney();
				double com = com_c.get_power();
				// 부가요소 +
				com += 2;
				user += 3;

				if (user > com)
				{
					reward_money = 1000;
					a += reward_money;
					DialogResult result = MessageBox.Show("User: " + user_c.car_Name() + "\nComputer: " + com_c.car_Name() + "\n 승리자: User, 상금: " + reward_money, "인천");
					// 메시지 창 종료
					if (result == DialogResult.OK)
					{
						this.Hide();
						Form1 form1 = new Form1(a);
						form1.FormClosed += Form1_FormClosed;
						form1.Show();
					}
				}
				else
				{
					reward_money = 200;
					a += reward_money;
					DialogResult result = MessageBox.Show("User: " + user_c.car_Name() + "\nComputer: " + com_c.car_Name() + "\n 승리자: Computer, 상금: " + reward_money, "인천");
					// 메시지 창 종료
					if (result == DialogResult.OK)
					{
						this.Hide();
						Form1 form1 = new Form1(a);
						form1.FormClosed += Form1_FormClosed;
						form1.Show();
					}
				}
			}
		}
		// 대구 맵
		private void pictureBox3_Click(object sender, EventArgs e)
		{
			// 사용자 차량 객체 불러오기
			double user = user_c.get_power();
			if (user == 0)
			{
				int a = Gacha.usedmoney();
				reward_money = 0;
				a += reward_money;
				DialogResult result1 = MessageBox.Show("사용자 차량을 선택하세요!", "The Car");
				// 사용자 차량 객체 선택 안했을시
				if (result1 == DialogResult.OK)
				{
					this.Hide();
					Form1 form1 = new Form1(a);
					form1.FormClosed += Form1_FormClosed;
					form1.Show();
				}
			}
			// 사용자 차량을 선택했다면
			else
			{
				int a = Gacha.usedmoney();
				double com = com_c.get_power();
				// 부가요소 +
				com += 7;
				user -= 2;

				if (user > com)
				{
					reward_money = 1000;
					a += reward_money;
					DialogResult result = MessageBox.Show("User: " + user_c.car_Name() + "\nComputer: " + com_c.car_Name() + "\n 승리자: User, 상금: " + reward_money, "대구");
					// 메시지 창 종료
					if (result == DialogResult.OK)
					{
						this.Hide();
						Form1 form1 = new Form1(a);
						form1.FormClosed += Form1_FormClosed;
						form1.Show();
					}
				}
				else
				{
					reward_money = 200;
					a += reward_money;
					DialogResult result = MessageBox.Show("User: " + user_c.car_Name() + "\nComputer: " + com_c.car_Name() + "\n 승리자: Computer, 상금: " + reward_money, "대구");
					// 메시지 창 종료
					if (result == DialogResult.OK)
					{
						this.Hide();
						Form1 form1 = new Form1(a);
						form1.FormClosed += Form1_FormClosed;
						form1.Show();
					}
				}
			}
		}
		// 광주 맵
		private void pictureBox5_Click(object sender, EventArgs e)
		{
			// 사용자 차량 객체 불러오기
			double user = user_c.get_power();
			if (user == 0)
			{
				int a = Gacha.usedmoney();
				reward_money = 0;
				a += reward_money;
				DialogResult result1 = MessageBox.Show("사용자 차량을 선택하세요!", "The Car");
				// 사용자 차량 객체 선택 안했을시
				if (result1 == DialogResult.OK)
				{
					this.Hide();
					Form1 form1 = new Form1(a);
					form1.FormClosed += Form1_FormClosed;
					form1.Show();
				}
			}
			// 사용자 차량을 선택했다면
			else
			{
				int a = Gacha.usedmoney();
				double com = com_c.get_power();
				// 부가요소 +
				com -= 13;
				user -= 10;

				if (user > com)
				{
					reward_money = 1000;
					a += reward_money;
					DialogResult result = MessageBox.Show("User: " + user_c.car_Name() + "\nComputer: " + com_c.car_Name() + "\n 승리자: User, 상금: " + reward_money, "광주");
					// 메시지 창 종료
					if (result == DialogResult.OK)
					{
						this.Hide();
						Form1 form1 = new Form1(a);
						form1.FormClosed += Form1_FormClosed;
						form1.Show();
					}
				}
				else
				{
					reward_money = 200;
					a += reward_money;
					DialogResult result = MessageBox.Show("User: " + user_c.car_Name() + "\nComputer: " + com_c.car_Name() + "\n 승리자: Computer, 상금: " + reward_money, "광주");
					// 메시지 창 종료
					if (result == DialogResult.OK)
					{
						this.Hide();
						Form1 form1 = new Form1(a);
						form1.FormClosed += Form1_FormClosed;
						form1.Show();
					}
				}
			}
		}
		// 울산
		private void pictureBox6_Click(object sender, EventArgs e)
		{
			// 사용자 차량 객체 불러오기
			double user = user_c.get_power();
			if (user == 0)
			{
				int a = Gacha.usedmoney();
				reward_money = 0;
				a += reward_money;
				DialogResult result1 = MessageBox.Show("사용자 차량을 선택하세요!", "The Car");
				// 사용자 차량 객체 선택 안했을시
				if (result1 == DialogResult.OK)
				{
					this.Hide();
					Form1 form1 = new Form1(a);
					form1.FormClosed += Form1_FormClosed;
					form1.Show();
				}
			}
			// 사용자 차량을 선택했다면
			else
			{
				int a = Gacha.usedmoney();
				double com = com_c.get_power();
				// 부가요소 +
				com += 23;
				user += 20;

				if (user > com)
				{
					reward_money = 1000;
					a += reward_money;
					DialogResult result = MessageBox.Show("User: " + user_c.car_Name() + "\nComputer: " + com_c.car_Name() + "\n 승리자: User, 상금: " + reward_money, "울산");
					// 메시지 창 종료
					if (result == DialogResult.OK)
					{
						this.Hide();
						Form1 form1 = new Form1(a);
						form1.FormClosed += Form1_FormClosed;
						form1.Show();
					}
				}
				else
				{
					reward_money = 200;
					a += reward_money;
					DialogResult result = MessageBox.Show("User: " + user_c.car_Name() + "\nComputer: " + com_c.car_Name() + "\n 승리자: Computer, 상금: " + reward_money, "울산");
					// 메시지 창 종료
					if (result == DialogResult.OK)
					{
						this.Hide();
						Form1 form1 = new Form1(a);
						form1.FormClosed += Form1_FormClosed;
						form1.Show();
					}
				}
			}
		}
		// 대전 맵
		private void pictureBox7_Click(object sender, EventArgs e)
		{
			// 사용자 차량 객체 불러오기
			double user = user_c.get_power();
			if (user == 0)
			{
				int a = Gacha.usedmoney();
				reward_money = 0;
				a += reward_money;
				DialogResult result1 = MessageBox.Show("사용자 차량을 선택하세요!", "The Car");
				// 사용자 차량 객체 선택 안했을시
				if (result1 == DialogResult.OK)
				{
					this.Hide();
					Form1 form1 = new Form1(a);
					form1.FormClosed += Form1_FormClosed;
					form1.Show();
				}
			}
			// 사용자 차량을 선택했다면
			else
			{
				int a = Gacha.usedmoney();
				double com = com_c.get_power();
				// 부가요소 +
				com += 7;
				user += 10;

				if (user > com)
				{
					reward_money = 1000;
					a += reward_money;
					DialogResult result = MessageBox.Show("User: " + user_c.car_Name() + "\nComputer: " + com_c.car_Name() + "\n 승리자: User, 상금: " + reward_money, "대전");
					// 메시지 창 종료
					if (result == DialogResult.OK)
					{
						this.Hide();
						Form1 form1 = new Form1(a);
						form1.FormClosed += Form1_FormClosed;
						form1.Show();
					}
				}
				else
				{
					reward_money = 200;
					a += reward_money;
					DialogResult result = MessageBox.Show("User: " + user_c.car_Name() + "\nComputer: " + com_c.car_Name() + "\n 승리자: Computer, 상금: " + reward_money, "대전");
					// 메시지 창 종료
					if (result == DialogResult.OK)
					{
						this.Hide();
						Form1 form1 = new Form1(a);
						form1.FormClosed += Form1_FormClosed;
						form1.Show();
					}
				}
			}
		}
		// 제주 맵
		private void pictureBox8_Click(object sender, EventArgs e)
		{
			// 사용자 차량 객체 불러오기
			double user = user_c.get_power();
			if (user == 0)
			{
				int a = Gacha.usedmoney();
				reward_money = 0;
				a += reward_money;
				DialogResult result1 = MessageBox.Show("사용자 차량을 선택하세요!", "The Car");
				// 사용자 차량 객체 선택 안했을시
				if (result1 == DialogResult.OK)
				{
					this.Hide();
					Form1 form1 = new Form1(a);
					form1.FormClosed += Form1_FormClosed;
					form1.Show();
				}
			}
			// 사용자 차량을 선택했다면
			else
			{
				int a = Gacha.usedmoney();
				double com = com_c.get_power();
				// 부가요소 +
				com += 6;
				user -= 1;

				if (user > com)
				{
					reward_money = 1000;
					a += reward_money;
					DialogResult result = MessageBox.Show("User: " + user_c.car_Name() + "\nComputer: " + com_c.car_Name() + "\n 승리자: User, 상금: " + reward_money, "제주");
					// 메시지 창 종료
					if (result == DialogResult.OK)
					{
						this.Hide();
						Form1 form1 = new Form1(a);
						form1.FormClosed += Form1_FormClosed;
						form1.Show();
					}
				}
				else
				{
					reward_money = 200;
					a += reward_money;
					DialogResult result = MessageBox.Show("User: " + user_c.car_Name() + "\nComputer: " + com_c.car_Name() + "\n 승리자: Computer, 상금: " + reward_money, "제주");
					// 메시지 창 종료
					if (result == DialogResult.OK)
					{
						this.Hide();
						Form1 form1 = new Form1(a);
						form1.FormClosed += Form1_FormClosed;
						form1.Show();
					}
				}
			}
		}
		// 뒤로가기 버튼으로 현재 폼에서 이전 폼을 연결함
		private void back_Click(object sender, EventArgs e)
		{
			this.Hide();
			int a = Gacha.usedmoney();
			Form1 form1 = new Form1(a);
			form1.FormClosed += Form1_FormClosed;
			form1.Show();
		}
		private void Form1_FormClosed(object sender, FormClosedEventArgs e)
		{
			this.Close();
		}
		// 콤보박스에서 값을 선택하면 label1에 해당값이 표현되게함
		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
			Factory factory = new Factory();
			for (int i = 1; i < 60; i++)
			{
				var a = factory.Factory_Cars(i);
				if (a.Name == comboBox1.Text)
				{
					label1.Text = "UserCar: " + a.Name;
					// 해당하는 객체의 이름을 user라는 메서드에 보냄
					user_c.user(a.Name);
				}
			}
		}
	}
}