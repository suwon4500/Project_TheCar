using CarStore;

namespace C_과제;

public class ReinForce : Garage
{
    //강화 => 1. 차량객
    
}