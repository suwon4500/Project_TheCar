﻿using CarStore;
using Project_TheCar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace C_과제
{
	public abstract class set_point
	{
		protected string car_name;
		protected double car_result;
	}

	// 컴퓨터 차
	public class Com : set_point
	{
		public Com()
		{
			Factory c_factory = new Factory();
			Random r = new Random();
			r = new Random(DateTime.Now.Millisecond);
			// 랜덤으로 값을 선택 c~s사이
			int x = r.Next(9,60);
			Car com_car = c_factory.Factory_Cars(x);
			car_name = com_car.Name;
			car_result = (com_car.Accel*1.0) + (com_car.MaxSpeed*0.3) - ((double)com_car.Weight *0.05);
		}
		// 컴퓨터 차 명칭
		public string car_Name()
		{
			return car_name;
		}
		// 컴퓨터 차의 능력
		public double get_power()
		{
			double z = car_result;
			return z;
		}
	}
	// 사용자 차
	public class User : set_point
	{
		// comboBox에서 선택한 값을 불러들임
		public void user(string name)
		{
			int ax = 0;
			Factory u_factory = new Factory();
			for(int i = 1; i < 60; i++)
			{
				var a = u_factory.Factory_Cars(i);
				if (a.Name == name)
				{
					// 해당 값과 불러들이 값이 같은 인덱스 번호를 가져옴
					ax = i;
				}
			}
			Car user_car = u_factory.Factory_Cars(ax);
			// 그 인덱스 번호에 대한 모든 값을 가져와 연산을함
			car_name = user_car.Name;
			car_result = (user_car.Accel * 1.0) + (user_car.MaxSpeed * 0.3) - ((double)user_car.Weight * 0.05);
		}
		public string car_Name()
		{
			return car_name;
		}
		public double get_power()
		{
			double z = car_result;
			return z;
		}
	}
}
