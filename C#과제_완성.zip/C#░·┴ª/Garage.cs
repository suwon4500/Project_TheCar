﻿using C_과제;
using Project_TheCar;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarStore
{
	public partial class Garage : Form
	{
		public string[] message = new string[60];
		public string[] title = new string[60];
		Gacha gacha = new Gacha();
		Factory factory = new Factory();
		public List<Button> CarButtons = new List<Button>();
		public List<Label> CarLabel = new List<Label>();
		public List<int> garage_car = new List<int>(new int[61]);
		public List<int> garage_count = new List<int>(new int[61]);
		public Garage(int usermoney)
		{
			InitializeComponent();
			this.ClientSize = new Size(840, 900); ;
			PaintMessage();
			Buttons();
			labels();
			Value();
			panel1.SendToBack();
			Gacha.usermoney = usermoney;
		}

		protected Garage()
		{
			
		}

		public void Value()
		{
			garage_car = Gacha.garage_car;
			garage_count = Gacha.garage_count;
			for (int i = 0; i < garage_car.Count; i++)
			{
				if (garage_car[i] != 0) //garage.garage_car가 0이 아니면, Factory 객체의 Factory_Cars 메서드를 호출 > Car 저장
				{
					Car user_car = factory.Factory_Cars(i);
					message[i] = "Name = " + user_car.Name + "\n" + "MaxSpeed = " + user_car.MaxSpeed + "\n" + "Accel = " + user_car.Accel + "\n" + "Weight = " + user_car.Weight + "\n" + "Class = " + user_car.Class + "\n" + "Explain = " + user_car.Explain;
					title[i] = "차량 개수 : " + garage_count[i];
					CarLabel[i].Text = "차량 개수 : " + garage_count[i];
				}
			}
			for (int i = 0; i < 59; i++)
			{
				CarLabel[i].Text = "차량 개수 : " + garage_count[i+1];
			}
		}
		public void Buttons()
		{
			int Width = 140, Height = 70;

			for (int i = 0; i < 59; i++)
			{
				CarButtons.Add(new Button());
				Car user_car = factory.Factory_Cars(i + 1);
				CarButtons[i].Text = user_car.Name;
				CarButtons[i].Size = new Size(120, 30);
				CarButtons[i].Click += (sender, e) => carButton_Click(sender, e, i);
				this.Controls.Add(CarButtons[i]);
			}

			int buttonIndex = 0;

			for (int x = 0; x < 59; x++)
			{
				int rowIndex = x % 6;
				int columnIndex = x / 6;

				CarButtons[buttonIndex].Location = new Point(10 + (Width * rowIndex), 150 + (Height * columnIndex));
				buttonIndex++;
			}
		}

		public void labels()
		{
			int Width = 140, Height = 70;

			for (int i = 0; i < 59; i++)
			{
				CarLabel.Add(new Label());
				CarLabel[i].Text = "차량 개수 : 0"; // 기본 텍스트 설정
				CarLabel[i].AutoSize = false; // 자동 조정 풀기
				CarLabel[i].TextAlign = ContentAlignment.MiddleCenter; // 글자 가운데 정렬
				CarLabel[i].Size = new Size(120, 30);
				this.Controls.Add(CarLabel[i]);
			}

			int labelIndex = 0;

			for (int x = 0; x < 59; x++)
			{
				int rowIndex = x % 6;
				int columnIndex = x / 6;

				CarLabel[labelIndex].Location = new Point(10 + (Width * rowIndex), 180 + (Height * columnIndex));
				labelIndex++;
			}
		}

		public void PaintMessage() // 차량을 보유하지 않을 경우, 차고에서 미보유 차량이라고 출력
		{
			for (int i = 0; i <60; i++)
			{
				title[i] = "차량 개수 : 0";
				message[i] = "미보유 차량입니다.";
			}
		}

		public void carButton_Click(object sender, EventArgs e, int x)
		{
			Button button = (Button)sender;
			int buttonIndex = CarButtons.IndexOf(button)+1;

			MessageBox.Show(message[buttonIndex], title[buttonIndex]);
		}

		private void button1_Click(object sender, EventArgs e)
		{
			this.Hide();
			Form1 form1 = new Form1();
			form1.FormClosed += Form1_FormClosed;
			form1.Show();
		}
		private void Form1_FormClosed(object sender, FormClosedEventArgs e)
		{
			this.Close();
		}
	}
}
