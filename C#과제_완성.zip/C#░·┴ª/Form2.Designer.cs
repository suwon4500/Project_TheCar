﻿namespace C_과제
{
	partial class Form2
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			pictureBox1 = new PictureBox();
			pictureBox2 = new PictureBox();
			pictureBox3 = new PictureBox();
			pictureBox4 = new PictureBox();
			pictureBox5 = new PictureBox();
			pictureBox6 = new PictureBox();
			pictureBox7 = new PictureBox();
			pictureBox8 = new PictureBox();
			textBox1 = new TextBox();
			textBox2 = new TextBox();
			textBox3 = new TextBox();
			textBox4 = new TextBox();
			textBox5 = new TextBox();
			textBox6 = new TextBox();
			textBox7 = new TextBox();
			textBox8 = new TextBox();
			textBox9 = new TextBox();
			back = new Button();
			label1 = new Label();
			comboBox1 = new ComboBox();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
			((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
			((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
			((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
			((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
			((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
			((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
			SuspendLayout();
			// 
			// pictureBox1
			// 
			pictureBox1.BackgroundImage = Properties.Resources.map6;
			pictureBox1.Location = new Point(23, 99);
			pictureBox1.Name = "pictureBox1";
			pictureBox1.Size = new Size(250, 150);
			pictureBox1.TabIndex = 4;
			pictureBox1.TabStop = false;
			pictureBox1.Click += pictureBox1_Click;
			// 
			// pictureBox2
			// 
			pictureBox2.BackgroundImage = Properties.Resources.map5;
			pictureBox2.Location = new Point(279, 99);
			pictureBox2.Name = "pictureBox2";
			pictureBox2.Size = new Size(250, 150);
			pictureBox2.TabIndex = 5;
			pictureBox2.TabStop = false;
			pictureBox2.Click += pictureBox2_Click;
			// 
			// pictureBox3
			// 
			pictureBox3.BackgroundImage = Properties.Resources.map8;
			pictureBox3.Location = new Point(791, 99);
			pictureBox3.Name = "pictureBox3";
			pictureBox3.Size = new Size(250, 150);
			pictureBox3.TabIndex = 6;
			pictureBox3.TabStop = false;
			pictureBox3.Click += pictureBox3_Click;
			// 
			// pictureBox4
			// 
			pictureBox4.BackgroundImage = Properties.Resources.map4;
			pictureBox4.Location = new Point(535, 99);
			pictureBox4.Name = "pictureBox4";
			pictureBox4.Size = new Size(250, 150);
			pictureBox4.TabIndex = 7;
			pictureBox4.TabStop = false;
			pictureBox4.Click += pictureBox4_Click;
			// 
			// pictureBox5
			// 
			pictureBox5.BackgroundImage = Properties.Resources.map9;
			pictureBox5.Location = new Point(23, 301);
			pictureBox5.Name = "pictureBox5";
			pictureBox5.Size = new Size(250, 150);
			pictureBox5.TabIndex = 8;
			pictureBox5.TabStop = false;
			pictureBox5.Click += pictureBox5_Click;
			// 
			// pictureBox6
			// 
			pictureBox6.BackgroundImage = Properties.Resources.map10;
			pictureBox6.Location = new Point(279, 301);
			pictureBox6.Name = "pictureBox6";
			pictureBox6.Size = new Size(250, 150);
			pictureBox6.TabIndex = 9;
			pictureBox6.TabStop = false;
			pictureBox6.Click += pictureBox6_Click;
			// 
			// pictureBox7
			// 
			pictureBox7.BackgroundImage = Properties.Resources.map7;
			pictureBox7.Location = new Point(535, 301);
			pictureBox7.Name = "pictureBox7";
			pictureBox7.Size = new Size(250, 150);
			pictureBox7.TabIndex = 10;
			pictureBox7.TabStop = false;
			pictureBox7.Click += pictureBox7_Click;
			// 
			// pictureBox8
			// 
			pictureBox8.BackgroundImage = Properties.Resources.map3;
			pictureBox8.Location = new Point(791, 301);
			pictureBox8.Name = "pictureBox8";
			pictureBox8.Size = new Size(250, 150);
			pictureBox8.TabIndex = 11;
			pictureBox8.TabStop = false;
			pictureBox8.Click += pictureBox8_Click;
			// 
			// textBox1
			// 
			textBox1.Font = new Font("맑은 고딕", 18F, FontStyle.Bold, GraphicsUnit.Point);
			textBox1.ForeColor = SystemColors.AppWorkspace;
			textBox1.Location = new Point(459, 12);
			textBox1.Name = "textBox1";
			textBox1.Size = new Size(140, 55);
			textBox1.TabIndex = 12;
			textBox1.Text = "맵 선택";
			textBox1.TextAlign = HorizontalAlignment.Center;
			// 
			// textBox2
			// 
			textBox2.Font = new Font("새굴림", 11F, FontStyle.Italic, GraphicsUnit.Point);
			textBox2.Location = new Point(114, 255);
			textBox2.Name = "textBox2";
			textBox2.Size = new Size(66, 33);
			textBox2.TabIndex = 13;
			textBox2.Text = "서울";
			textBox2.TextAlign = HorizontalAlignment.Center;
			// 
			// textBox3
			// 
			textBox3.Font = new Font("새굴림", 11F, FontStyle.Italic, GraphicsUnit.Point);
			textBox3.Location = new Point(889, 457);
			textBox3.Name = "textBox3";
			textBox3.Size = new Size(66, 33);
			textBox3.TabIndex = 14;
			textBox3.Text = "제주";
			// 
			// textBox4
			// 
			textBox4.Font = new Font("새굴림", 11F, FontStyle.Italic, GraphicsUnit.Point);
			textBox4.Location = new Point(889, 256);
			textBox4.Name = "textBox4";
			textBox4.Size = new Size(66, 33);
			textBox4.TabIndex = 15;
			textBox4.Text = "대구";
			textBox4.TextAlign = HorizontalAlignment.Center;
			// 
			// textBox5
			// 
			textBox5.Font = new Font("새굴림", 11F, FontStyle.Italic, GraphicsUnit.Point);
			textBox5.Location = new Point(634, 457);
			textBox5.Name = "textBox5";
			textBox5.Size = new Size(66, 33);
			textBox5.TabIndex = 16;
			textBox5.Text = "대전";
			textBox5.TextAlign = HorizontalAlignment.Center;
			// 
			// textBox6
			// 
			textBox6.Font = new Font("새굴림", 11F, FontStyle.Italic, GraphicsUnit.Point);
			textBox6.Location = new Point(634, 256);
			textBox6.Name = "textBox6";
			textBox6.Size = new Size(66, 33);
			textBox6.TabIndex = 17;
			textBox6.Text = "인천";
			textBox6.TextAlign = HorizontalAlignment.Center;
			// 
			// textBox7
			// 
			textBox7.Font = new Font("새굴림", 11F, FontStyle.Italic, GraphicsUnit.Point);
			textBox7.Location = new Point(361, 255);
			textBox7.Name = "textBox7";
			textBox7.Size = new Size(66, 33);
			textBox7.TabIndex = 18;
			textBox7.Text = "부산";
			textBox7.TextAlign = HorizontalAlignment.Center;
			// 
			// textBox8
			// 
			textBox8.Font = new Font("새굴림", 11F, FontStyle.Italic, GraphicsUnit.Point);
			textBox8.Location = new Point(361, 457);
			textBox8.Name = "textBox8";
			textBox8.Size = new Size(66, 33);
			textBox8.TabIndex = 19;
			textBox8.Text = "울산";
			textBox8.TextAlign = HorizontalAlignment.Center;
			// 
			// textBox9
			// 
			textBox9.Font = new Font("새굴림", 11F, FontStyle.Italic, GraphicsUnit.Point);
			textBox9.Location = new Point(114, 457);
			textBox9.Name = "textBox9";
			textBox9.Size = new Size(66, 33);
			textBox9.TabIndex = 20;
			textBox9.Text = "광주";
			textBox9.TextAlign = HorizontalAlignment.Center;
			// 
			// back
			// 
			back.Location = new Point(60, 12);
			back.Name = "back";
			back.Size = new Size(177, 42);
			back.TabIndex = 22;
			back.Text = "뒤로가기";
			back.UseVisualStyleBackColor = true;
			back.Click += back_Click;
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Location = new Point(736, 59);
			label1.Name = "label1";
			label1.Size = new Size(75, 25);
			label1.TabIndex = 24;
			label1.Text = "UserCar";
			// 
			// comboBox1
			// 
			comboBox1.FormattingEnabled = true;
			comboBox1.Location = new Point(736, 12);
			comboBox1.Name = "comboBox1";
			comboBox1.Size = new Size(266, 33);
			comboBox1.TabIndex = 25;
			comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
			// 
			// Form2
			// 
			AutoScaleDimensions = new SizeF(10F, 25F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(1058, 544);
			Controls.Add(comboBox1);
			Controls.Add(label1);
			Controls.Add(back);
			Controls.Add(textBox9);
			Controls.Add(textBox8);
			Controls.Add(textBox7);
			Controls.Add(textBox6);
			Controls.Add(textBox5);
			Controls.Add(textBox4);
			Controls.Add(textBox3);
			Controls.Add(textBox2);
			Controls.Add(textBox1);
			Controls.Add(pictureBox8);
			Controls.Add(pictureBox7);
			Controls.Add(pictureBox6);
			Controls.Add(pictureBox5);
			Controls.Add(pictureBox4);
			Controls.Add(pictureBox3);
			Controls.Add(pictureBox2);
			Controls.Add(pictureBox1);
			Name = "Form2";
			Text = "THE CAR";
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
			((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
			((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
			((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
			((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
			((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
			((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion
		private PictureBox pictureBox1;
		private PictureBox pictureBox2;
		private PictureBox pictureBox3;
		private PictureBox pictureBox4;
		private PictureBox pictureBox5;
		private PictureBox pictureBox6;
		private PictureBox pictureBox7;
		private PictureBox pictureBox8;
		private TextBox textBox1;
		private TextBox textBox2;
		private TextBox textBox3;
		private TextBox textBox4;
		private TextBox textBox5;
		private TextBox textBox6;
		private TextBox textBox7;
		private TextBox textBox8;
		private TextBox textBox9;
		private ListBox listBox1;
		private Button back;
		private Label label1;
		private ComboBox comboBox1;
	}
}