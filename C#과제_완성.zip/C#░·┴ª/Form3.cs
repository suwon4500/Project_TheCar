using C_과제;
using Project_TheCar;

namespace CarStore
{
	public partial class Form3 : Form
	{
		Gacha gacha = new Gacha();
		GachaMachine gachaMachine = new GachaMachine();
		public Form3()
		{
			InitializeComponent();
			label1.Text = Gacha.UpdateUserMoneyLabel();
		}


		// A~D 1회 뽑기
		private void button1_Click(object sender, EventArgs e)
		{
			gachaMachine.gachaMachine1(1);
			label1.Text = Gacha.UpdateUserMoneyLabel();
		}

		// A~D 5회 뽑기
		private void button2_Click(object sender, EventArgs e)
		{
			gachaMachine.gachaMachine1(5);
			//gacha.buttonn2();
			label1.Text = Gacha.UpdateUserMoneyLabel();
		}

		// S~B 1회 뽑기
		private void button3_Click(object sender, EventArgs e)
		{
			gachaMachine.gachaMachine2(1);
			label1.Text = Gacha.UpdateUserMoneyLabel();
		}

		// S~B 5회 뽑기
		private void button4_Click(object sender, EventArgs e)
		{
			gachaMachine.gachaMachine2(5);
			label1.Text = Gacha.UpdateUserMoneyLabel();
		}

		// 차고 폼 불러들임
		private void button5_Click(object sender, EventArgs e)
		{
			this.Hide();
			int a = Gacha.usedmoney();
			Garage garage = new Garage(a);
			garage.FormClosed += Garage_FormClosed;
			garage.Show();
		}
		private void Garage_FormClosed(object sender, FormClosedEventArgs e)
		{
			this.Close();
		}
		// 뒤로가기 버튼
		private void button6_Click(object sender, EventArgs e)
		{
			this.Hide();
			int a = Gacha.usedmoney();
			Form1 form1 = new Form1(a);
			form1.FormClosed += Form1_FormClosed;
			form1.Show();
		}
		private void Form1_FormClosed(object sender, FormClosedEventArgs e)
		{
			this.Close();
		}
	}
}