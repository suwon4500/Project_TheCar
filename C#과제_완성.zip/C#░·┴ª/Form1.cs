using System.Security.Cryptography.X509Certificates;
using CarStore;
using Project_TheCar;

namespace C_과제
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			// 초기화
			InitializeComponent();
			this.Size = new Size(1080, 600);
		}

		public Form1(int userdmoney)
		{
			// Form1을 다시 부를건데 여기에는 money에 대한 값이 저장되어 있어야 한다
			InitializeComponent();
			this.Size = new Size(1080, 600);
			Gacha.usermoney = userdmoney;
		}
		private void Form1_Load(object sender, EventArgs e)
		{
			// 배경 이미지 파일의 경로
			string imagePath = @"..\..\..\..\image\background.png";
			Image backgroundImage = Image.FromFile(imagePath);
			this.BackgroundImage = backgroundImage;
		}

		// 상점 버튼
		private void button2_Click(object sender, EventArgs e)
		{
			// this.Hide는 해당 폼을 숨기고
			this.Hide();
			// 새로운 폼을 생성해
			Form3 form3 = new Form3();
			// 그 폼을 끄면 해당 메서드를 사용함
			form3.FormClosed += Form3_FormClosed;
			// 새로 생성한 폼을 나타냄
			form3.Show();
		}
		private void Form3_FormClosed(object sender, FormClosedEventArgs e)
		{
			this.Close(); // form3를 종료하면 현재 창도 종료되게!
		}

		// 차고 버튼
		private void button3_Click(object sender, EventArgs e)
		{
			this.Hide();
			int a = Gacha.usedmoney();
			Garage garage1 = new Garage(a);
			garage1.FormClosed += Garage_FormClosed;
			garage1.Show();
		}
		private void Garage_FormClosed(object sender, FormClosedEventArgs e)
		{
			this.Close(); // form3를 종료하면 현재 창도 종료되게!
		}

		// 게임 시작 버튼
		private void button1_Click_1(object sender, EventArgs e)
		{
			this.Hide();
			Form2 form2 = new Form2(Gacha.garage_count[60]);
			form2.FormClosed += Form2_FormClosed;
			form2.Show();
		}
		private void Form2_FormClosed(object sender, FormClosedEventArgs e)
		{
			this.Close(); // form2를 종료하면 현재 창도 종료되게!
		}
	}
}