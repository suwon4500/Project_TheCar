﻿namespace C_과제
{
	partial class Form1
	{
		/// <summary>
		///  Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		///  Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		///  Required method for Designer support - do not modify
		///  the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			Start = new Button();
			Store = new Button();
			Inventory = new Button();
			SuspendLayout();
			// 
			// Start
			// 
			Start.BackColor = SystemColors.Highlight;
			Start.FlatStyle = FlatStyle.Flat;
			Start.Font = new Font("맑은 고딕", 18F, FontStyle.Bold, GraphicsUnit.Point);
			Start.Location = new Point(423, 397);
			Start.Name = "Start";
			Start.Size = new Size(202, 77);
			Start.TabIndex = 0;
			Start.Text = "게임 시작";
			Start.UseVisualStyleBackColor = false;
			Start.Click += button1_Click_1;
			// 
			// Store
			// 
			Store.BackColor = Color.White;
			Store.FlatStyle = FlatStyle.Flat;
			Store.Font = new Font("맑은 고딕", 18F, FontStyle.Bold, GraphicsUnit.Point);
			Store.Location = new Point(80, 70);
			Store.Name = "Store";
			Store.Size = new Size(202, 77);
			Store.TabIndex = 1;
			Store.Text = "상점";
			Store.UseVisualStyleBackColor = false;
			Store.Click += button2_Click;
			// 
			// Inventory
			// 
			Inventory.BackColor = Color.White;
			Inventory.FlatStyle = FlatStyle.Flat;
			Inventory.Font = new Font("맑은 고딕", 18F, FontStyle.Bold, GraphicsUnit.Point);
			Inventory.Location = new Point(772, 70);
			Inventory.Name = "Inventory";
			Inventory.Size = new Size(202, 77);
			Inventory.TabIndex = 2;
			Inventory.Text = "차고";
			Inventory.UseVisualStyleBackColor = false;
			Inventory.Click += button3_Click;
			// 
			// Form1
			// 
			AutoScaleDimensions = new SizeF(10F, 25F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(1058, 544);
			Controls.Add(Inventory);
			Controls.Add(Store);
			Controls.Add(Start);
			Name = "Form1";
			Text = "THE CAR";
			Load += Form1_Load;
			ResumeLayout(false);
		}

		#endregion

		private Button Start;
		private Button Store;
		private Button Inventory;
	}
}