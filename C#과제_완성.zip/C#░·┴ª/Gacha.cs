﻿using CarStore;
using Project_TheCar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_과제
{

	internal class Gacha
	{
		// 사용자가 보유한 돈
		public static int usermoney = 5000000;
		// 사용자 차량을 넣어두는 곳
		public static List<int> garage_car = new List<int>(new int[62]);
		public static List<int> garage_count = new List<int>(new int[62]);
		protected Random r = new Random();
		Factory factory = new Factory(); // Car.cs에 Factory class를 불러온 것

		// 현재 사용자가 가지고 있는 돈을 출력함
		public static string UpdateUserMoneyLabel()
		{
			return $"Money: {usermoney}원";
		}

		// 사용했던 돈을 반환함
		public static int usedmoney()
		{
			return usermoney;
		}

		public string RankGacha(char rank)
		{
			int randint = 0;
			if (rank == 'D')
			{
				randint = r.Next(1, 9); // D랭크 차들 1~8까지 랜덤 발생하고 randint 변수에 저장
			}
			else if (rank == 'C')
			{
				randint = r.Next(9, 33);
			}
			else if (rank == 'B')
			{
				randint = r.Next(33, 48);
			}
			else if (rank == 'A')
			{
				randint = r.Next(48, 56);
			}
			else if (rank == 'S')
			{
				randint = r.Next(56, 60);
			}

			Car user_car = factory.Factory_Cars(randint); // user_car 라는 변수에 Car Class의 저장되어 있는 모든 값 저장 Name,Class 등등
			garage_car[user_car.Number] = user_car.Number;
			garage_count[user_car.Number] += 1;

			return user_car.Class + "등급 " + user_car.Name; // Car class에 저장되어있는 변수 불러와서 값 반환
		}

	}

	internal class GachaMachine : Gacha
	{
		public void gachaMachine1(int count)
		{
			int basemoney = 1200;
			DialogResult result;
			result = MessageBox.Show("뽑기 가격은 " + basemoney * count + "원입니다. 뽑기를 진행하시겠습니까?", "뽑기 진행",
				MessageBoxButtons.YesNo); // 뽑기 전에 뽑기 가격 알려주고, 뽑기 할 건지 선택할 수 있게

			if (result == DialogResult.Yes) // 뽑기를 한다고 하면 진행하는 코드
			{
				if (usermoney >= basemoney * count)
				{
					usermoney -= basemoney * count; // 돈 차감
					UpdateUserMoneyLabel();
					string message = "";
					string saveMessage = $"====== 뽑기 결과 ======\n\n";
					for (int i = 0; i < count; i++)
					{
						double percentage = r.NextDouble() * 100; // NextDouble 0.0~1.0 사이의 모든 값 랜덤 * 100 0~100이하의 모든 값

						if (percentage >= 90)
						{
							message = RankGacha('D') + "\n";
							saveMessage += message;
						}
						else if (percentage >= 30)
						{
							message = RankGacha('C') + "\n";
							saveMessage += message;
						}
						else if (percentage >= 10)
						{
							message = RankGacha('B') + "\n";
							saveMessage += message;
						}
						else if (percentage >= 0)
						{
							message = RankGacha('A') + "\n";
							saveMessage += message;
						}
					}

					saveMessage += "\n차량을 뽑았습니다!";
					MessageBox.Show(saveMessage);
				}
				else if (usermoney < basemoney * count) // 뽑기를 진행한다고 했으나, 돈이 없을 경우 출력할 메세지
				{
					MessageBox.Show("보유한 돈이 부족합니다");
				}
			}
			else // 뽑기를 안 한다고 했을 경우에는 뽑기를 종료한다는 메세지 출력하기
			{
				MessageBox.Show("뽑기를 종료합니다.");
			}
		}

		public void gachaMachine2(int count)
		{
			int basemoney = 4000;
			DialogResult result;
			result = MessageBox.Show("뽑기 가격은 " + basemoney * count + "원입니다. 뽑기를 진행하시겠습니까?", "뽑기 진행",
				MessageBoxButtons.YesNo); // 뽑기 전에 뽑기 가격 알려주고, 뽑기 할 건지 선택할 수 있게

			if (result == DialogResult.Yes) // 뽑기를 한다고 하면 진행하는 코드
			{
				if (usermoney >= basemoney * count)
				{
					usermoney -= basemoney * count; // 돈 차감
					UpdateUserMoneyLabel();
					string message = "";
					string saveMessage = $"====== 뽑기 결과 ======\n\n";
					for (int i = 0; i < count; i++)
					{
						double percentage = r.NextDouble() * 100; // NextDouble 0.0~1.0 사이의 모든 값 랜덤 * 100 0~100이하의 모든 값

						if (percentage >= 26.5458)
						{
							message = RankGacha('B') + "\n";
							saveMessage += message;
						}
						else if (percentage >= 5.55)
						{
							message = RankGacha('A') + "\n";
							saveMessage += message;
						}
						else if (percentage >= 0)
						{
							message = RankGacha('S') + "\n";
							saveMessage += message;
						}
					}
					saveMessage += "\n차량을 뽑았습니다!";
					MessageBox.Show(saveMessage);
				}
				else if (usermoney < basemoney * count) // 뽑기를 진행한다고 했으나, 돈이 없을 경우 출력할 메세지
				{
					MessageBox.Show("보유한 돈이 부족합니다");
				}
			}
			else // 뽑기를 안 한다고 했을 경우에는 뽑기를 종료한다는 메세지 출력하기
			{
				MessageBox.Show("뽑기를 종료합니다.");
			}
		}
	}
}